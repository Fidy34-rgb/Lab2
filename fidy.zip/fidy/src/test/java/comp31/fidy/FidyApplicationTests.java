package comp31.fidy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FidyApplicationTests {

	@Test
	void contextLoads() {
	}

}
