package comp31.fidy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FidyApplication {

	public static void main(String[] args) {
		SpringApplication.run(FidyApplication.class, args);
	}

}
